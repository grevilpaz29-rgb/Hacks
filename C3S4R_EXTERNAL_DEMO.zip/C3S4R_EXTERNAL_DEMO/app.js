document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===btn));
  document.querySelectorAll('.panel').forEach(x=>x.classList.toggle('active',x.id===btn.dataset.tab));
}));
document.querySelectorAll('.switch input').forEach(input=>input.addEventListener('change',()=>{
  toast(input.checked?'Vista previa activada':'Vista previa desactivada');
}));
let timer;
function toast(message){
  const el=document.getElementById('toast');el.textContent=message;el.classList.add('show');
  clearTimeout(timer);timer=setTimeout(()=>el.classList.remove('show'),1700);
}
